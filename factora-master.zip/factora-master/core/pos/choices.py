PAYMENT_CONDITION = (
    ('contado', 'Contado'),
    ('credito', 'Credito'),
)

PAYMENT_METHOD = (
    ('efectivo', 'Efectivo'),
    ('tarjeta_debito_credito', 'Tarjeta de Debito / Credito'),
    ('efectivo_tarjeta', 'Efectivo y Tarjeta'),
)

VOUCHER = (
    ('ticket', 'Ticket'),
    ('factura', 'Factura'),
)