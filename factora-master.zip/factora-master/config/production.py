from .settings import *
ALLOWED_HOSTS = ['*']
DEBUG = False